/* Общий движок эффектов: 3D-сборка треугольника, наклон при наведении,
   появление блоков при прокрутке, подсветка курсора. Подключается на всех сайтах. */
(function () {
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const rnd = (a, b) => a + Math.random() * (b - a);

  /* ---------- 3D-треугольник: части разлетаются и собираются ---------- */
  const tri = document.getElementById('tri');
  if (tri) {
    const stage = tri.closest('.tri-stage');
    const pieces = Array.from(tri.querySelectorAll('.piece'));

    function scatter() {
      pieces.forEach((p) => {
        p.style.transition = 'none';
        p.style.opacity = '0';
        p.style.transform =
          `translate3d(${rnd(-700, 700)}px,${rnd(-450, 450)}px,${rnd(-900, 200)}px) ` +
          `rotateX(${rnd(-720, 720)}deg) rotateY(${rnd(-720, 720)}deg)`;
      });
    }

    function assemble(speed) {
      pieces.forEach((p, i) => {
        const d = (i * 0.16) / speed;
        p.style.transition = `transform ${1.9 / speed}s cubic-bezier(.16,.84,.24,1) ${d}s, opacity .6s ${d}s`;
        p.style.transform = p.dataset.final;
        p.style.opacity = '1';
      });
    }

    function run(speed) {
      if (reduce) {
        pieces.forEach((p) => { p.style.transition = 'none'; p.style.transform = p.dataset.final; p.style.opacity = '1'; });
        return;
      }
      scatter();
      requestAnimationFrame(() => requestAnimationFrame(() => assemble(speed)));
    }

    stage.addEventListener('pointermove', (e) => {
      const r = stage.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const y = (e.clientY - r.top) / r.height - 0.5;
      tri.style.transform = `rotateX(${(-y * 50).toFixed(1)}deg) rotateY(${(x * 70).toFixed(1)}deg)`;
    });
    stage.addEventListener('pointerleave', () => { tri.style.transform = ''; });
    stage.addEventListener('click', () => run(1.25));

    run(1);
    window.TRI = { run };
  }

  /* ---------- наклон карточек при наведении ---------- */
  if (!reduce) {
    document.querySelectorAll('[data-tilt]').forEach((el) => {
      el.addEventListener('pointermove', (e) => {
        const r = el.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width - 0.5;
        const y = (e.clientY - r.top) / r.height - 0.5;
        el.style.transform = `perspective(900px) rotateX(${(-y * 12).toFixed(2)}deg) rotateY(${(x * 14).toFixed(2)}deg) translateZ(8px)`;
      });
      el.addEventListener('pointerleave', () => { el.style.transform = ''; });
    });
  }

  /* ---------- появление блоков при прокрутке ---------- */
  const io = new IntersectionObserver((entries) => {
    entries.forEach((en) => {
      if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
    });
  }, { threshold: 0.15 });
  document.querySelectorAll('[data-reveal]').forEach((el, i) => {
    el.style.setProperty('--d', (i % 4) * 0.09 + 's');
    io.observe(el);
  });

  /* ---------- подсветка за курсором (для тёмного стиля) ---------- */
  if (!reduce) {
    document.addEventListener('pointermove', (e) => {
      document.documentElement.style.setProperty('--mx', e.clientX + 'px');
      document.documentElement.style.setProperty('--my', e.clientY + 'px');
    });
  }

  /* ---------- шапка меняется при прокрутке ---------- */
  const header = document.querySelector('header');
  if (header) {
    const onScroll = () => header.classList.toggle('scrolled', window.scrollY > 30);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }
})();
