/* Общая корзина на localStorage: добавление, количество, сумма, оформление. */
(function () {
  const KEY = 'mfk-cart';
  const cart = JSON.parse(localStorage.getItem(KEY) || '{}');
  const fmt = (n) => n.toLocaleString('ru-RU') + ' ₽';
  const save = () => localStorage.setItem(KEY, JSON.stringify(cart));

  function render() {
    const keys = Object.keys(cart);
    let count = 0, total = 0;
    const items = document.getElementById('items');
    if (items) {
      items.innerHTML = keys.length
        ? keys.map((k) => {
            const it = cart[k];
            count += it.qty; total += it.qty * it.price;
            return `<div class="line"><div><b>${k}</b><small>${fmt(it.price)}</small></div>
              <div class="qty"><button onclick="changeQty('${k}',-1)">−</button><span>${it.qty}</span><button onclick="changeQty('${k}',1)">+</button></div></div>`;
          }).join('')
        : '<div class="empty">Корзина пуста. Выберите что-нибудь вкусное!</div>';
    }
    keys.forEach((k) => { count += 0; });
    const c = keys.reduce((s, k) => s + cart[k].qty, 0);
    const t = keys.reduce((s, k) => s + cart[k].qty * cart[k].price, 0);
    const tEl = document.getElementById('total'); if (tEl) tEl.textContent = fmt(t);
    const cEl = document.getElementById('count'); if (cEl) cEl.textContent = c;
  }

  function bump() {
    const b = document.getElementById('cartBtn');
    if (!b) return;
    b.classList.remove('bump'); void b.offsetWidth; b.classList.add('bump');
  }

  window.toggleCart = function () {
    document.getElementById('cart').classList.toggle('open');
    document.getElementById('overlay').classList.toggle('open');
  };
  window.addToCart = function (name, price) {
    cart[name] = cart[name] || { price, qty: 0 };
    cart[name].qty++;
    save(); render(); bump();
  };
  window.changeQty = function (name, d) {
    if (!cart[name]) return;
    cart[name].qty += d;
    if (cart[name].qty <= 0) delete cart[name];
    save(); render();
  };
  window.submitOrder = function (e) {
    e.preventDefault();
    if (!Object.keys(cart).length) { alert('Сначала добавьте товары в корзину'); return; }
    alert('Спасибо! Заказ принят. Мы свяжемся с вами для подтверждения.');
    for (const k in cart) delete cart[k];
    save(); render(); e.target.reset(); toggleCart();
  };

  render();
})();
